Studio1 Sans 1.0
================

The Studio1 brand typeface. Two weights: Regular (400) and Medium (500).

INSTALL ON YOUR COMPUTER (Figma, Keynote, Word, Google Slides via desktop)
  Desktop/Studio1Sans-Regular.ttf
  Desktop/Studio1Sans-Medium.ttf
  Mac: double-click each file and choose Install Font.
  Windows: right-click each file and choose Install (or Install for all users).
  Then pick "Studio1 Sans" from the font menu.

USE ON A WEBSITE
  Web/Studio1Sans-Regular.woff2
  Web/Studio1Sans-Medium.woff2
  Web/studio1-sans.css   (link it, then use font-family: "Studio1 Sans")

MATCH THE STUDIO1 LOOK EXACTLY
  Weights       Regular 400 and Medium 500 only. No bold, no italics.
  Body          14px, line height 1.3
  Tracking      -3% (-0.03em). Headlines 32px and up use -4%.
  Headings      Medium 500. Hierarchy comes from size, not weight.
  Colors        Ink #0A0A0A, Gray #707070, Surface #F2F2F2, Sky #DDF4FF

In Figma: Letter spacing -3%, Line height 130%.
In Keynote or Word: Character spacing about -0.4pt at 14pt.

LICENSE
  Studio1 Sans is a renamed version of Inter by Rasmus Andersson and is
  under the SIL Open Font License 1.1 (see LICENSE.txt). It is free to
  use, embed and share, but the font files cannot be sold on their own.
